# Student Management System (Java)

A beginner-friendly, menu-driven Java console application for managing student records.

## Features
- Add a student
- View all students
- Search for a student by ID
- Update student details
- Delete a student
- Prevent duplicate student IDs
- Validate numeric input

## Technologies
- Java
- Object-Oriented Programming (classes, objects, encapsulation)
- ArrayList
- Scanner

## Requirements
- JDK 14 or later (the menu uses switch-arrow syntax)

## Run the project
Open a terminal in this folder and run:

```bash
javac Main.java
java Main
```

## Note
This beginner version stores records in memory using an `ArrayList`. Records are cleared when the application exits. It does not use MySQL or permanent file storage.
